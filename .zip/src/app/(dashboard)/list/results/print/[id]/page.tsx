import ReportCardSheet from "@/components/ReportCardSheet";
import PrintButton from "@/components/PrintButton";
import { prisma } from "@/lib/prisma";
import { notFound } from "next/navigation";
import { auth } from "@clerk/nextjs/server";

const ReportPrintPage = async ({ params }: { params: Promise<{ id: string }> }) => {
  const { id } = await params;
  const { userId, sessionClaims } = await auth();
  const role = (sessionClaims?.metadata as any)?.role?.toLowerCase();



  const getOrdinal = (n: number) => {
    const s = ["th", "st", "nd", "rd"];
    const v = n % 100;
    return n + (s[(v - 20) % 10] || s[v] || s[0]);
  };


  // 1. Get Current Academic Year
  const currentYear = await prisma.academicYear.findFirst({ where: { isCurrent: true } });
  const yearLabel = currentYear?.name || "2025/2026";
  const academicYearId = currentYear?.id || 1;

  // 2. Fetch Student with Attendance and Results
  const student = await prisma.student.findUnique({
    where: { id: id },
    include: {
      class: {
        include: {
          _count: { select: { subjects: true } },
          supervisor: true,
        }
      },
      // 🎯 Fix: Ensure this matches your schema (attendance or attendances)
      attendances: {
        where: { academicYearId: academicYearId }
      },
      results: {
        include: {
          subject: { select: { name: true } },
          exam: { include: { subject: true } },
          assignment: { include: { subject: true } },
        },
        orderBy: { id: 'desc' }
      },
    },
  });

  if (!student) return notFound();

 const parent = await prisma.parent.findUnique({
  where: { clerkId: userId! },
  select: { id: true },
});

if (role === "parent" && student.parentId !== parent?.id) {
  return notFound();
}

  // 4. Attendance Aggregation Logic

  const attendanceRecords = student.attendances || [];
  const uniqueDates = Array.from(new Set(attendanceRecords.map((a) => a.date.toISOString().split("T")[0])));
  const daysPresent = uniqueDates.filter((date) =>
  attendanceRecords.some(
    (a) =>
      a.date.toISOString().split("T")[0] === date &&
      a.status === "PRESENT"
  )
).length;

  // 5. Ranking & Subject Mapping Logic
  const subjectMap: Record<string, any> = {};
  student.results.forEach((res) => {
    const name = res.subject?.name || res.exam?.subject?.name || "Unknown";
    if (!subjectMap[name]) {
      subjectMap[name] = {
       ca: Number(res.testScore) + Number(res.assignmentScore),
        exam: Number(res.examScore),
        total: Number(res.totalScore),
        grade: res.grade ?? "F"
      };
    }
  });

  const totalPoints = student.results.reduce((acc, curr) => acc + Number(curr.totalScore), 0);
  const studentAverage = student.results.length > 0 ? totalPoints / student.results.length : 0;
  const className = student.class?.name ?? "";

  // 6. Principal Remarks Logic
  const getPrincipalComment = (avg: number) => {
    if (avg >= 80) return "Exceptional performance! Keep it up.";
    if (avg >= 60) return "Good performance. Room for more growth.";
    return "Standard below average. See Principal.";
  };

  // --- 6.5 RANKING LOGIC ---
  // Fetch all students in the same class to compare performance
  const allClassStudents = await prisma.student.findMany({
    where: { classId: student.classId },
    include: {
      results: {
        where: { academicYearId: academicYearId },
      },
    },
  });

  // Map every student to their average score
  // Map every student to their average score
const classRankings = allClassStudents
  .map((s) => {
    const total = s.results.reduce(
      (acc, curr) => acc + Number(curr.totalScore),
      0
    );

    const avg = s.results.length > 0 ? total / s.results.length : 0;

    return {
      id: s.id,
      avg,
      hasResults: s.results.length > 0,
    };
  })
  .filter((s) => s.hasResults)
  .sort((a, b) => b.avg - a.avg);

  // Find the current student's index in that sorted list
  const hasResults = student.results.length > 0;

const currentPosition = hasResults
  ? classRankings.findIndex((r) => r.id === student.id) + 1
  : 0;

const totalStudentsInClass = allClassStudents.length;

  // 7. FINAL DATA MERGE
  const finalData = {
    studentName: `${student.name} ${student.surname}`,
    studentId: student.id,
    className: className,
    academicYear: yearLabel,
    principalComment: getPrincipalComment(studentAverage),


    position: hasResults ? getOrdinal(currentPosition) : "-",

    attendance: {
      present: daysPresent,
      total: uniqueDates.length
    },
    subjects: Object.entries(subjectMap).map(([name, scores]) => ({
      name,
      ca: scores.ca,
      exam: scores.exam,
      total: scores.total.toString(),
      level: className.toLowerCase().includes("sss") ? scores.grade : ""
    }))
  };

  return (
    <div className="bg-slate-100 min-h-screen py-10 print:bg-white print:py-0">
      <div className="max-w-[210mm] mx-auto px-4 mb-6 flex justify-end print:hidden">
        <PrintButton />
      </div>

      <div className="max-w-[210mm] mx-auto bg-white shadow-2xl print:shadow-none">
        {/* 🎯 ONLY ONE CALL TO THE COMPONENT */}
        <ReportCardSheet data={finalData} />
      </div>
    </div>
  );
};

export default ReportPrintPage;