"use client";

import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import InputField from "../InputField";
import { createExam, updateExam } from "@/lib/server-actions";
import {
  Dispatch,
  SetStateAction,
  startTransition,
  useActionState,
  useEffect,
} from "react";
import { toast } from "react-toastify";
import { useRouter } from "next/navigation";
import { examSchema, ExamSchema } from "@/lib/validation";

const ExamForm = ({
  type,
  data,
  setOpen,
  relatedData,
}: {
  type: "create" | "update";
  data?: any;
  setOpen: Dispatch<SetStateAction<boolean>>;
  relatedData?: any;
}) => {
  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm<ExamSchema>({
    resolver: zodResolver(examSchema) as any,
    defaultValues: {
      title: data?.title ?? "",
      description: data?.description ?? "",
      examType: data?.examType,
      totalMarks: data?.totalMarks ?? 100,
      passMark: data?.passMark ?? 40,
      examDate: data?.examDate
        ? new Date(data.examDate)
        : undefined,
      startTime: data?.startTime
        ? new Date(data.startTime)
        : undefined,
      endTime: data?.endTime
        ? new Date(data.endTime)
        : undefined,
      venue: data?.venue ?? "",
      levelId: data?.levelId
        ? Number(data.levelId)
        : undefined,
      subjectId: data?.subjectId
        ? Number(data.subjectId)
        : undefined,
      teacherId: data?.teacherId ?? "",
      id: data?.id ? Number(data.id) : undefined,
    },
  });

  const [state, formAction, isPending] = useActionState(
    type === "create" ? createExam : updateExam,
    {
      success: false,
      error: false,
      message: "",
    }
  );

  const router = useRouter();

  useEffect(() => {
    if (state.success) {
      toast.success(
        state.message ||
          `Exam ${
            type === "create" ? "created" : "updated"
          } successfully!`
      );

      setOpen(false);
      router.refresh();
    }

    if (state.error) {
      toast.error(state.message || "Something went wrong.");
    }
  }, [state, setOpen, router, type]);

  const {
    levels = [],
    streams = [],
    subjects = [],
    teachers = [],
  } = relatedData || {};

  const juniorLevels = levels.filter((level: any) =>
    String(level.name).toUpperCase().startsWith("JSS")
  );

  const seniorLevels = levels.filter((level: any) =>
    String(level.name).toUpperCase().startsWith("SSS")
  );

  const getExistingLevelId = () => {
    if (data?.levelId) {
      return Number(data.levelId);
    }

    if (data?.class?.levelId) {
      return Number(data.class.levelId);
    }

    return undefined;
  };

  const existingLevelId = getExistingLevelId();

  const existingStreamId =
    data?.class?.streamId
      ? Number(data.class.streamId)
      : data?.streamId
      ? Number(data.streamId)
      : undefined;

  const formatDateTime = (date: Date | string | undefined) => {
    if (!date) return "";

    const d = new Date(date);

    if (Number.isNaN(d.getTime())) return "";

    const year = d.getFullYear();
    const month = String(d.getMonth() + 1).padStart(2, "0");
    const day = String(d.getDate()).padStart(2, "0");
    const hours = String(d.getHours()).padStart(2, "0");
    const minutes = String(d.getMinutes()).padStart(2, "0");

    return `${year}-${month}-${day}T${hours}:${minutes}`;
  };

  const onSubmit = handleSubmit(
    (formData) => {
      startTransition(() => {
        formAction({
          ...formData,

          id: type === "update"
            ? Number(data?.id)
            : undefined,

          levelId: Number(formData.levelId),
          subjectId: Number(formData.subjectId),
          teacherId: formData.teacherId,

          totalMarks: Number(formData.totalMarks),
          passMark: Number(formData.passMark),

          examDate: new Date(formData.examDate),
          startTime: new Date(formData.startTime),
          endTime: new Date(formData.endTime),
        });
      });
    },
    (validationErrors) => {
      console.log("EXAM VALIDATION ERRORS:", validationErrors);
    }
  );

  return (
    <form
      className="flex flex-col w-full max-w-2xl mx-auto"
      onSubmit={onSubmit}
    >
      {/* HEADER */}
      <div className="sticky top-0 text-center bg-white z-50 px-6 py-5 border-b">
        <h1 className="text-xl md:text-2xl font-black text-slate-800 uppercase">
          {type === "create" ? "Create New" : "Update"}{" "}
          <span className="text-rubixPurple">Exam</span>
        </h1>
      </div>

      <div className="px-6 py-6 space-y-8 pb-28">

        {/* UPDATE ID */}
        {type === "update" && data?.id && (
          <input
            type="hidden"
            {...register("id")}
            value={data.id}
            readOnly
          />
        )}

        {/* BASIC INFORMATION */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">

          <InputField
            label="Exam Title"
            name="title"
            register={register}
            defaultValue={data?.title}
            error={errors.title}
          />

          <InputField
            label="Exam Date"
            name="examDate"
            type="date"
            register={register}
            defaultValue={
              data?.examDate
                ? new Date(data.examDate)
                    .toISOString()
                    .slice(0, 10)
                : undefined
            }
            error={errors.examDate}
          />

          <InputField
            label="Start Time"
            name="startTime"
            type="datetime-local"
            register={register}
            defaultValue={formatDateTime(data?.startTime)}
            error={errors.startTime}
          />

          <InputField
            label="End Time"
            name="endTime"
            type="datetime-local"
            register={register}
            defaultValue={formatDateTime(data?.endTime)}
            error={errors.endTime}
          />

          <InputField
            label="Total Marks"
            name="totalMarks"
            type="number"
            register={register}
            defaultValue={data?.totalMarks ?? 100}
            error={errors.totalMarks}
          />

          <InputField
            label="Pass Mark"
            name="passMark"
            type="number"
            register={register}
            defaultValue={data?.passMark ?? 40}
            error={errors.passMark}
          />

        </div>

        {/* SUBJECT */}
        <div className="flex flex-col gap-2">
          <label className="text-xs font-bold text-slate-500 uppercase">
            Subject
          </label>

          <select
            {...register("subjectId")}
            defaultValue={data?.subjectId ?? ""}
            className="w-full p-3 rounded-xl border border-slate-200 bg-slate-50 text-sm"
          >
            <option value="">Select Subject</option>

            {subjects.map((subject: any) => (
              <option
                key={subject.id}
                value={subject.id}
              >
                {subject.name}
              </option>
            ))}
          </select>

          {errors.subjectId?.message && (
            <p className="text-xs text-red-500">
              {errors.subjectId.message.toString()}
            </p>
          )}
        </div>

        {/* EXAM TYPE */}
        <div className="flex flex-col gap-2">
          <label className="text-xs font-bold text-slate-500 uppercase">
            Exam Type
          </label>

          <select
            {...register("examType")}
            defaultValue={data?.examType ?? ""}
            className="w-full p-3 rounded-xl border border-slate-200 bg-slate-50 text-sm"
          >
            <option value="">Select Exam Type</option>

            <option value="CA">CA</option>
            <option value="MID_TERM">Mid Term</option>
            <option value="EXAM">Examination</option>
            <option value="MOCK">Mock Examination</option>
          </select>

          {errors.examType?.message && (
            <p className="text-xs text-red-500">
              {errors.examType.message.toString()}
            </p>
          )}
        </div>

        {/* TARGET LEVEL */}
        <div className="flex flex-col gap-4">

          <div>
            <h2 className="text-sm font-black text-slate-700 uppercase">
              Target Class
            </h2>

            <p className="text-xs text-slate-400 mt-1">
              Select the level or SSS stream that should receive this exam.
            </p>
          </div>

          {/* JUNIOR */}
          <div className="bg-slate-50 border border-slate-200 rounded-2xl p-5">

            <h3 className="text-sm font-black text-rubixPurple uppercase mb-4">
              Junior Secondary School
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">

              {juniorLevels.map((level: any) => (
                <label
                  key={level.id}
                  className="flex items-center gap-3 bg-white border border-slate-200 rounded-xl p-4 cursor-pointer hover:border-rubixPurple transition"
                >
                  <input
                    type="radio"
                    value={level.id}
                    {...register("levelId")}
                    defaultChecked={
                      existingLevelId === Number(level.id)
                    }
                    className="w-4 h-4 accent-rubixPurple"
                  />

                  <span className="font-bold text-slate-700">
                    {level.name}
                  </span>
                </label>
              ))}

            </div>
          </div>

          {/* SENIOR */}
          <div className="bg-slate-50 border border-slate-200 rounded-2xl p-5">

            <h3 className="text-sm font-black text-rubixPurple uppercase mb-4">
              Senior Secondary School
            </h3>

            <div className="space-y-5">

              {seniorLevels.map((level: any) => {

                const levelStreams = streams.filter(
                  (stream: any) => {
                    if (!stream.classes) return false;

                    return stream.classes.some(
                      (classItem: any) =>
                        Number(classItem.levelId) ===
                        Number(level.id)
                    );
                  }
                );

                return (
                  <div key={level.id}>

                    <h4 className="text-xs font-black text-slate-500 uppercase mb-3">
                      {level.name}
                    </h4>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">

                      {/* GENERAL */}
                      <label className="flex items-center gap-3 bg-white border border-slate-200 rounded-xl p-4 cursor-pointer hover:border-rubixPurple transition">

                        <input
                          type="radio"
                          value={level.id}
                          {...register("levelId")}
                          defaultChecked={
                            existingLevelId === Number(level.id) &&
                            !existingStreamId
                          }
                          className="w-4 h-4 accent-rubixPurple"
                        />

                        <span className="font-bold text-slate-700">
                          {level.name} - General
                        </span>

                      </label>

                      {/* STREAMS */}
                      {levelStreams.map(
                        (stream: any) => (
                          <label
                            key={`${level.id}-${stream.id}`}
                            className="flex items-center gap-3 bg-white border border-slate-200 rounded-xl p-4 cursor-pointer hover:border-rubixPurple transition"
                          >

                            <input
                              type="radio"
                              value={level.id}
                              {...register("levelId")}
                              defaultChecked={
                                existingLevelId ===
                                  Number(level.id) &&
                                existingStreamId ===
                                  Number(stream.id)
                              }
                              className="w-4 h-4 accent-rubixPurple"
                            />

                            <span className="font-bold text-slate-700">
                              {level.name} - {stream.name}
                            </span>

                          </label>
                        )
                      )}

                    </div>
                  </div>
                );
              })}

            </div>
          </div>

          {errors.levelId?.message && (
            <p className="text-xs text-red-500">
              {errors.levelId.message.toString()}
            </p>
          )}

        </div>

        {/* TEACHER */}
        <div className="flex flex-col gap-2">

          <label className="text-xs font-bold text-slate-500 uppercase">
            Teacher
          </label>

          <select
            {...register("teacherId")}
            defaultValue={data?.teacherId ?? ""}
            className="w-full p-3 rounded-xl border border-slate-200 bg-slate-50 text-sm"
          >
            <option value="">Select Teacher</option>

            {teachers.map((teacher: any) => (
              <option
                key={teacher.id}
                value={teacher.id}
              >
                {teacher.firstName} {teacher.lastName}
              </option>
            ))}
          </select>

          {errors.teacherId?.message && (
            <p className="text-xs text-red-500">
              {errors.teacherId.message.toString()}
            </p>
          )}

        </div>

        {/* VENUE */}
        <InputField
          label="Venue"
          name="venue"
          register={register}
          defaultValue={data?.venue ?? ""}
          error={errors.venue}
        />

        {/* DESCRIPTION */}
        <div className="flex flex-col gap-2">

          <label className="text-xs font-bold text-slate-500 uppercase">
            Description
          </label>

          <textarea
            {...register("description")}
            defaultValue={data?.description ?? ""}
            rows={4}
            className="w-full p-4 rounded-xl border border-slate-200 bg-slate-50 text-sm resize-none"
            placeholder="Optional exam description..."
          />

          {errors.description?.message && (
            <p className="text-xs text-red-500">
              {errors.description.message.toString()}
            </p>
          )}

        </div>

      </div>

      {/* FOOTER */}
      <div className="sticky bottom-0 bg-white px-6 py-4 border-t z-50">

        {state.error && (
          <p className="text-sm text-red-500 mb-3 text-center">
            {state.message || "Something went wrong."}
          </p>
        )}

        <button
          type="submit"
          disabled={isPending}
          className="w-full bg-slate-900 text-white py-4 rounded-2xl font-bold hover:bg-rubixPurple transition-all shadow-lg disabled:opacity-50"
        >
          {isPending
            ? type === "create"
              ? "Creating..."
              : "Updating..."
            : type === "create"
            ? "Create Exam"
            : "Update Exam"}
        </button>

      </div>
    </form>
  );
};

export default ExamForm;