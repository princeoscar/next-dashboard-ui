"use client";

import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import {
  Dispatch,
  SetStateAction,
  startTransition,
  useActionState,
  useEffect,
} from "react";
import { useRouter } from "next/navigation";
import { toast } from "react-toastify";

import InputField from "../InputField";

import {
  createExpense,
  updateExpense,
} from "@/lib/server-actions";

import {
  expenseSchema,
  ExpenseSchema,
} from "@/lib/validation";

const paymentMethods = [
  "CASH",
  "BANK_TRANSFER",
  "CARD",
  "PAYSTACK",
  "POS",
];

const ExpenseForm = ({
  type,
  data,
  setOpen,
}: {
  type: "create" | "update";
  data?: any;
  setOpen: Dispatch<SetStateAction<boolean>>;
  relatedData?: any;
}) => {
  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm<ExpenseSchema>({
    resolver: zodResolver(expenseSchema) as any,
  });

  const [state, formAction] = useActionState(
    type === "create"
      ? createExpense
      : updateExpense,
    {
      success: false,
      error: false,
      message: "",
    }
  );

  const router = useRouter();

  const onSubmit = handleSubmit((formData) => {
    startTransition(() => {
      formAction(formData);
    });
  });

  useEffect(() => {
    if (state.success) {
      toast.success(
        `Expense ${type === "create"
          ? "created"
          : "updated"
        } successfully.`
      );

      setOpen(false);
      router.refresh();
    }

    if (state.error) {
      toast.error(
        state.message ?? "Something went wrong."
      );
    }
  }, [state, router, setOpen, type]);

  return (
    <form
      onSubmit={onSubmit}
      className="flex flex-col gap-6"
    >
      <h1 className="text-xl font-bold">
        {type === "create"
          ? "Add Expense"
          : "Update Expense"}
      </h1>

      {data && (
        <input
          type="hidden"
          {...register("id")}
          defaultValue={data.id}
        />
      )}

      <InputField
        label="Title"
        name="title"
        register={register}
        defaultValue={data?.title}
        error={errors.title}
      />

      <InputField
        label="Description"
        name="description"
        register={register}
        defaultValue={data?.description}
        error={errors.description}
      />

      <InputField
        label="Amount"
        type="number"
        name="amount"
        register={register}
        defaultValue={data?.amount?.toString()}
        error={errors.amount}
        inputProps={{
          step: "0.01",
        }}
      />

      <InputField
        label="Category"
        name="category"
        register={register}
        defaultValue={data?.category}
        error={errors.category}
      />

      <div className="flex flex-col gap-2">
        <label className="text-xs font-bold">
          Payment Method
        </label>

        <select
          {...register("paymentMethod")}
          defaultValue={
            data?.paymentMethod ?? ""
          }
          className="ring-[1.5px] ring-gray-300 rounded-md p-3"
        >
          <option value="">
            Select Payment Method
          </option>

          {paymentMethods.map((method) => (
            <option
              key={method}
              value={method}
            >
              {method.replaceAll("_", " ")}
            </option>
          ))}
        </select>

        {errors.paymentMethod && (
          <p className="text-xs text-red-500">
            {errors.paymentMethod.message}
          </p>
        )}
      </div>

      <InputField
        label="Expense Date"
        type="date"
        name="spentAt"
        register={register}
        defaultValue={
          data?.spentAt
            ? new Date(data.spentAt)
              .toISOString()
              .split("T")[0]
            : undefined
        }
        error={errors.spentAt}
      />

      <button
        className="bg-red-600 text-white py-3 rounded-lg font-semibold"
      >
        {type === "create"
          ? "Create Expense"
          : "Update Expense"}
      </button>
    </form>
  );
};

export default ExpenseForm;