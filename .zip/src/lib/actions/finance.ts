"use server";

import { auth } from "@clerk/nextjs/server";
import { revalidatePath } from "next/cache";
import { prisma } from "@/lib/prisma";
import { generateReceiptNumber } from "@/lib/actions/paymentReceipt";

export const getRecentPayments = async () => {
  const { sessionClaims } = await auth();

  const schoolId = (sessionClaims?.metadata as any)?.schoolId;

  if (!schoolId) {
    throw new Error("School not found.");
  }

  return prisma.paymentRecord.findMany({
    where: {
      schoolId,
    },

    include: {
      allocation: {
        include: {
          category: true,
        },
      },

      balance: {
        include: {
          student: {
            include: {
              class: true,
              parent: true,
            },
          },
        },
      },
    },

    orderBy: {
      paymentDate: "desc",
    },

    take: 10,
  });
};

export const createIncome = async (data: any) => {
  const { sessionClaims } = await auth();

  const schoolId = (sessionClaims?.metadata as any)?.schoolId;

  if (!schoolId) {
    return {
      success: false,
      error: true,
      message: "School not found.",
    };
  }

  try {
    await prisma.income.create({
      data: {
        title: data.title,
        description: data.description,
        amount: data.amount,
        category: data.category,
        paymentMethod: data.paymentMethod,
        receivedAt: data.receivedAt,
        schoolId,
      },
    });

    revalidatePath("/admin/finance");

    return {
      success: true,
      error: false,
    };
  } catch (error) {
    console.error(error);

    return {
      success: false,
      error: true,
      message: "Failed to create income.",
    };
  }
};

export const updateIncome = async (data: any) => {
  try {
    await prisma.income.update({
      where: {
        id: data.id,
      },

      data: {
        title: data.title,
        description: data.description,
        amount: data.amount,
        category: data.category,
        paymentMethod: data.paymentMethod,
        receivedAt: data.receivedAt,
      },
    });

    revalidatePath("/admin/finance");

    return {
      success: true,
      error: false,
    };
  } catch (error) {
    console.error(error);

    return {
      success: false,
      error: true,
      message: "Failed to update income.",
    };
  }
};

export const deleteIncome = async (prevState: any, formData: FormData) => {
  try {
    const id = Number(formData.get("id"));

    await prisma.income.delete({
      where: {
        id,
      },
    });

    revalidatePath("/admin/finance");

    return {
      success: true,
      error: false,
    };
  } catch (error) {
    console.error(error);

    return {
      success: false,
      error: true,
      message: "Failed to delete income.",
    };
  }
};


import { prisma } from "@/lib/prisma";

export const calculateStudentBalance = async (student: any) => {
  // 1. Fetch the active year INSIDE the function
  const activeYear = await prisma.academicYear.findFirst({
    where: { isCurrent: true },
  });

  // 2. Handle missing year
  if (!activeYear) return 0;

  // 3. Fetch the fees
  const fees = await prisma.feeStructure.findFirst({
    where: {
      levelId: student.levelId,
      academicYearId: activeYear.id,
    },
  });

  // 4. Fetch the payments
  const totalPaid = await prisma.paymentRecord.aggregate({
    where: {
      balance: {
        studentId: student.id,
      },
      allocation: {
        academicYear: activeYear.name,
      },
    },
    _sum: {
      amountPaid: true,
    },
  });

  const balance =
    Number(fees?.amount || 0) -
    Number(totalPaid._sum.amountPaid || 0);

  return balance;
};