import type { Config } from "tailwindcss";

const config: Config = {
  content: [
    "./src/pages/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/components/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/app/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: {
    extend: {
      backgroundImage: {
        "gradient-radial": "radial-gradient(var(--tw-gradient-stops))",
        "gradient-conic":
          "conic-gradient(from 180deg at 50% 50%, var(--tw-gradient-stops))",
      },
      colors:{
        rubixSky:"#C3EBFA",
        rubixSkyLight:"#EDF9FD",
        rubixPurple:"#CFCEFF",
        rubixPurpleLight:"#F1F0FF",
        rubixYellow:"#FAE27C",
        rubixYellowLight: "#FEFCE8",
        rubixPink: "#FFD6E0",
      rubixPinkLight: "#FFF0F3",
      }
    },
  },
  plugins: [],
};
export default config;
